$(document).ready(function() {
    $('.toggle-sidebar').click(function() {
        $('body').toggleClass('sidebar-collapse');
    });

    $('[data-toggle="tooltip"]').tooltip();

    $('.user-profile').click(function() {
        $('.user-profile-dropdown').slideToggle();
    });

    $('.register-view .edit-register-form').click(function() {
        $(this).parents('.register-view').addClass('edit-register-view');
    });

    $('#register-view').on('hidden.bs.modal', function() {
        $(this).removeClass('edit-register-view');
    })

    $(function() {
        $('input.datepicker').daterangepicker({
            singleDatePicker: true,
            timePicker: true,
            startDate: moment().startOf('hour'),
            endDate: moment().startOf('hour').add(32, 'hour'),
            locale: {
                format: 'DD-MM-YYYY, hh:mm A'
            }
        });
        $('input.dob').daterangepicker({
            singleDatePicker: true,
            showDropdowns: true,
            minYear: 1990,
            maxYear: parseInt(moment().format('YYYY'), 10)
        });
    });

    //add disease
});

var source = ["Fever", "Cold", "Cough"];

$(function() {
    $("#add-disease").autocomplete({
        source: function(request, response) {
            response($.ui.autocomplete.filter(source, request.term));
        }
    });

    $(".add-disease").on("click", function() {
        var newDisease = $("#add-disease").val().trim();
        if (newDisease && source.indexOf(newDisease) === -1) {
            source.push(newDisease);
        }
        $("#add-disease").val("");
        $('.add-disease-data').append(newDisease + ", ");
    });
});